#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v gcc >/dev/null 2>&1; then
  echo "GCC is missing. Install it with: sudo apt update && sudo apt install build-essential"
  exit 1
fi
gcc -std=c11 -Wall -Wextra -O2 kernel_monitor.c -o kernel_monitor
echo "Compiled successfully."
# Open the live monitor in a separate terminal when a supported terminal is available.
if command -v gnome-terminal >/dev/null 2>&1; then
  gnome-terminal --title="Kernel Monitor Output" -- bash -lc "cd '$PWD' && ./kernel_monitor; echo; read -rp 'Monitor stopped. Press Enter to close...'"
elif command -v x-terminal-emulator >/dev/null 2>&1; then
  x-terminal-emulator -e bash -lc "cd '$PWD' && ./kernel_monitor; echo; read -rp 'Monitor stopped. Press Enter to close...'"
elif command -v konsole >/dev/null 2>&1; then
  konsole --new-tab -e bash -lc "cd '$PWD' && ./kernel_monitor"
else
  echo "No supported graphical terminal launcher was found."
  echo "Open a SECOND Ubuntu terminal, cd to this folder, and run: ./kernel_monitor"
  echo "This fallback is common in WSL without a Linux desktop."
fi
