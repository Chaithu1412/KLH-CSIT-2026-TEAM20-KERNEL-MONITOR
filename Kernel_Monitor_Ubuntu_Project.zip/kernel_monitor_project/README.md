# Kernel Monitor (OSSP)

A C command-line monitor for Ubuntu/Linux based on `/proc`. It displays CPU utilization, memory usage, uptime, monitor PID, and a sample of process PID/PPID/state/command. The display refreshes every two seconds.

## Build and run

```bash
sudo apt update
sudo apt install build-essential
chmod +x run_kernel_monitor.sh
./run_kernel_monitor.sh
```

The launcher compiles the program and tries to open the monitor in a separate terminal. If your Ubuntu environment has no graphical terminal (common with WSL), open a second Ubuntu terminal and run:

```bash
cd /path/to/kernel_monitor_project
./kernel_monitor
```

Stop the monitor with Ctrl+C in the output terminal.

## Notes
- This is a user-space monitor reading kernel-provided information through `/proc`; it does not modify the kernel.
- The process list is a small sample of numeric `/proc` entries, not a CPU-ranked top list.
- CPU percentage is estimated from the change in aggregate `/proc/stat` counters over a short sampling interval.
