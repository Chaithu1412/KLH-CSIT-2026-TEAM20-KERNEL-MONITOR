#define _DEFAULT_SOURCE
#include <dirent.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define PROC_STAT "/proc/stat"
#define PROC_MEMINFO "/proc/meminfo"
#define PROC_UPTIME "/proc/uptime"
#define MAX_PROCESSES 12

typedef struct { unsigned long long idle, total; } CpuTimes;

static int read_cpu_times(CpuTimes *out) {
    FILE *f = fopen(PROC_STAT, "r");
    if (!f) return -1;
    char line[512];
    unsigned long long user=0,nice=0,system=0,idle=0,iowait=0,irq=0,softirq=0,steal=0;
    if (!fgets(line, sizeof line, f)) { fclose(f); return -1; }
    fclose(f);
    if (sscanf(line, "cpu %llu %llu %llu %llu %llu %llu %llu %llu",
        &user,&nice,&system,&idle,&iowait,&irq,&softirq,&steal) < 4) return -1;
    out->idle = idle + iowait;
    out->total = user + nice + system + idle + iowait + irq + softirq + steal;
    return 0;
}

static double cpu_usage(void) {
    CpuTimes a,b;
    if (read_cpu_times(&a) != 0) return -1.0;
    usleep(150000);
    if (read_cpu_times(&b) != 0 || b.total <= a.total) return -1.0;
    unsigned long long total=b.total-a.total, idle=b.idle-a.idle;
    return 100.0 * (double)(total-idle)/(double)total;
}

static void memory_info(unsigned long long *total, unsigned long long *available) {
    *total = *available = 0;
    FILE *f = fopen(PROC_MEMINFO, "r");
    if (!f) return;
    char key[64], unit[32];
    unsigned long long value;
    while (fscanf(f, "%63s %llu %31s", key, &value, unit) == 3) {
        if (strcmp(key, "MemTotal:") == 0) *total = value;
        else if (strcmp(key, "MemAvailable:") == 0) *available = value;
        if (*total && *available) break;
    }
    fclose(f);
}

static double uptime_seconds(void) {
    FILE *f = fopen(PROC_UPTIME, "r");
    double seconds = 0.0;
    if (f) { (void)fscanf(f, "%lf", &seconds); fclose(f); }
    return seconds;
}

static void format_uptime(double seconds, char *buf, size_t size) {
    long s=(long)seconds, days=s/86400, hours=(s%86400)/3600, mins=(s%3600)/60;
    snprintf(buf, size, "%ldd %02ldh %02ldm", days, hours, mins);
}

static void process_info(void) {
    DIR *dir = opendir("/proc");
    if (!dir) { perror("opendir /proc"); return; }
    printf("TOP PROCESSES (sample of numeric /proc entries)\n");
    printf("%-8s %-8s %-7s %s\n", "PID", "PPID", "STATE", "COMMAND");
    struct dirent *entry;
    int shown=0;
    while ((entry = readdir(dir)) != NULL && shown < MAX_PROCESSES) {
        char *end=NULL;
        long pid=strtol(entry->d_name, &end, 10);
        if (entry->d_name[0]=='\0' || !end || *end!='\0' || pid<=0) continue;
        char path[256], line[1024], comm[256]="?", state='?';
        long ppid=0;
        snprintf(path, sizeof path, "/proc/%ld/stat", pid);
        FILE *f=fopen(path, "r");
        if (!f) continue; /* Process may have exited between readdir and fopen. */
        if (!fgets(line, sizeof line, f)) { fclose(f); continue; }
        fclose(f);
        char *left=strchr(line, '('), *right=strrchr(line, ')');
        if (!left || !right || right<=left) continue;
        size_t n=(size_t)(right-left-1);
        if (n>=sizeof comm) n=sizeof comm-1;
        memcpy(comm, left+1, n); comm[n]='\0';
        /* After ')' fields start with state, then PPID. */
        if (sscanf(right+2, "%c %ld", &state, &ppid) != 2) continue;
        printf("%-8ld %-8ld %-7c %s\n", pid, ppid, state, comm);
        shown++;
    }
    closedir(dir);
    if (!shown) printf("(No process entries could be read.)\n");
}

int main(void) {
    signal(SIGINT, SIG_DFL);
    for (;;) {
        unsigned long long total_kb=0, avail_kb=0;
        memory_info(&total_kb, &avail_kb);
        double cpu=cpu_usage();
        double up=uptime_seconds();
        char upbuf[64];
        format_uptime(up, upbuf, sizeof upbuf);
        unsigned long long used_kb = total_kb > avail_kb ? total_kb-avail_kb : 0;

        printf("\033[2J\033[H");
        printf("============================================================\n");
        printf("                    KERNEL MONITOR\n");
        printf("============================================================\n");
        printf("Monitor PID : %ld\n", (long)getpid());
        printf("CPU Usage   : ");
        if (cpu < 0) printf("Unavailable\n"); else printf("%.2f%%\n", cpu);
        if (total_kb) {
            printf("Memory      : %.2f / %.2f GiB used (%.1f%%)\n",
                used_kb/1048576.0, total_kb/1048576.0,
                total_kb ? 100.0*(double)used_kb/(double)total_kb : 0.0);
            printf("Available   : %.2f GiB\n", avail_kb/1048576.0);
        } else printf("Memory      : Unavailable\n");
        printf("System Uptime: %s\n", upbuf);
        printf("Refresh     : every 2 seconds | Press Ctrl+C to stop\n\n");
        process_info();
        fflush(stdout);
        sleep(2);
    }
    return 0;
}
